# Blackjack
This is a blackjack OOP for the CS591

Group Members:

1. Ethan Timoteo Go
2. Sean Chun

How to Compile:
We compiled our code using the Eclispse compiler. Our main function is in the Exec.Class. Once Compiled properly, grader should expect to see a statement "Welcome! Let's play BlackJack!" and then a input statement asking for the player's name. 
